<?php namespace Acme\Presenters;

use Laracasts\Presenter\Presenter;

class BiayalastmilevendorPresenter extends Presenter {

}