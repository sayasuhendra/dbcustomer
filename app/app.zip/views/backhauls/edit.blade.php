@extends('layouts.scaffold')

@section('main')

<h2 align="center">Edit Data Backhaul</h2>

{{ Form::model($backhaul, array('method' => 'PATCH', 'route' => array('backhauls.update', $backhaul->id))) }}

<div class="col-md-6 col-md-offset-3">
    <div class="panel panel-default">
        <div class="panel-body">
                <div class="form-horizontal">
                <div class="form-group">
                    {{ Form::label('circuitidbackhaul', 'Circuit ID Backhaul:', ['class' => 'col-sm-3']) }}
                    <div class="col-sm-9">
                    {{ Form::input('number', 'circuitidbackhaul', null, ['class' => 'form-control']) }}</div>
                </div>
                    <div class="form-group">
                        {{ Form::label('namavendor', 'Nama Vendor:', ['class' => 'col-sm-3']) }}
                        <div class="col-sm-9">{{ Form::select('namavendor', $namavendor, null, ['class' => 'form-control']) }}</div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-3">
                        {{ Form::label('activated_at', 'Start Date :') }}
                        </div>
                        <div class="col-sm-9">
                        {{ Form::input('date', 'activated_at', null, ['class' => 'form-control']) }}
                        </div>
                    </div>
                    <div class="form-group">
                        {{ Form::label('lokasixconnect', 'Lokasi XConnect:', ['class' => 'col-sm-3']) }}
                        <div class="col-sm-9">{{ Form::text('lokasixconnect', null, ['class' => 'form-control']) }}</div>
                    </div>
                    <div class="form-group">
                        {{ Form::label('switchterkoneksi', 'Switch Terkoneksi:', ['class' => 'col-sm-3']) }}
                        <div class="col-sm-9">{{ Form::select('switchterkoneksi', $namaswitch, null, ['class' => 'form-control']) }}</div>
                    </div>
                    <div class="form-group">
                        {{ Form::label('portterkoneksi', 'Port Terkoneksi:', ['class' => 'col-sm-3']) }}
                        <div class="col-sm-9">{{ Form::input('number', 'portterkoneksi', null, ['class' => 'form-control']) }}</div>
                    </div>
                    <div class="form-group row">
                        {{ Form::label('bandwidth', 'Bandwidth:', ['class' => 'col-sm-3']) }}
                        <div class="col-sm-9">
                            <div class="form-inline">
                                {{ Form::text('bandwidth', null, ['class' => 'form-control', 'id' => 'bandwidth']) }}
                                {{ Form::select('satuan', ['Mbps' => 'Mbps', 'Kbps' => 'Kbps'], null, ['class' => 'form-control']) }}
                            </div>            
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div align="center">
                        
                        {{ Form::submit('Update', array('class' => 'btn btn-primary')) }}
                        {{ link_to_route('backhauls.show', 'Cancel', $backhaul->id, array('class' => 'btn btn-default')) }}
                        </div>
                    </div>
                </div>

        </div>
    </div>

			

{{ Form::close() }}

@if ($errors->any())
	<ul>
		{{ implode('', $errors->all('<li class="error">:message</li>')) }}
	</ul>
@endif

@stop
