@extends('layouts.scaffold')

@section('style-atas')

<style>
    a:hover {
     cursor:pointer;
    }

    th { font-size: 12px; }
    td { font-size: 12px; }

</style>

@stop

@section('script-atas')

<!-- google chart -->

<script type="text/javascript" src="https://www.google.com/jsapi"></script>

<script type="text/javascript">
      google.load("visualization", "1", {packages:["corechart"]});
      google.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Customer', 'Margin per Circuit'],
          @foreach($costumercircuits as $costumercircuit)
          [ {{{ $costumercircuit->namasite }}},     {{{ $costumercircuit->present()->untung }}} ],
          @endforeach
        ]);

        var options = {
          title: 'Data Untung Customer Ini Per Circuits',
          is3D: true,

        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
      }
    </script>


@stop

@section('main')

<h1 align="center">Data Customer Detail</h1>

<p>{{ link_to_route('customers.index', 'Kembali Ke Daftar Customer') }}</p>

	        <div class="col-md-7">
	            <div class="panel panel-default">
	              <div class="panel-heading">
	                <h3 class="panel-title">Data Customer {{{ $customer->nama }}}</h3>
	              </div>
	              <div class="panel-body">
					    <dl class="dl-horizontal">
						<dt>Customer ID</dt>
						<dd>{{{ $customer->customerid }}}</dd>
						<dt>Nama Perusahaan</dt>
						<dd>{{{ $customer->nama }}}</dd>
						<dt>Alamat Perusahaan</dt>
						<dd>{{{ $customer->alamat }}}</dd>
						<dt>Level Customer</dt>
						<dd>{{{ $customer->level }}}</dd>
                        <dt>NPWP</dt>
                        <dd>{{{ $customer->npwp }}}</dd>
                        <dt>Alamat NPWP</dt>
                        <dd>{{{ $customer->alamatnpwp }}}</dd>
                        <dt>Keterangan</dt>
                        <dd>{{{ $customer->keterangan }}}</dd>
	                    </dl>
	              </div>
	            </div>
	        </div>

	        <div class="col-md-5">
	            <div class="panel panel-default">
	              <div class="panel-heading">
	                <h3 class="panel-title">Daftar Contact Customer {{{ $customer->nama }}}</h3>
	              </div>
	              <div class="panel-body">
					    <dl class="dl-horizontal">
							@foreach ($contacts as $contact)
								<dt>Contact Bagian {{{ $contact->bagian }}}</dt>
								<dd><a id="contactButton{{{ $contact->id }}}" data-toggle="tooltip" data-placement="left" title="{{{ $contact->email }}} | {{{ $contact->telepon }}}" data-content="{{{ $contact->keterangan }}} "> {{{ $contact->cp }}} | {{{ $contact->jabatan }}} </a></dd>
							@endforeach
	                    </dl>
	              </div>
	            </div>
	        </div>

	        
	        	<table id="datasbp" class="table table-striped table-bordered">
	        		<thead>
	        			<tr>
	        				<th>Circuit ID</th>
                            <th>Namasite</th>
                            <th>Alamat</th>
                            <th>Layanan</th>
                            <th>BW</th>
                            <th>MRC Circuit</th>
                            <th>Cir ID Backhaul</th>
                            <th>Cir ID Vendor</th>
                            <th>Nama Vendor</th>
                            <th>MRC Vendor</th>
                            <th>Untung</th>
                            <th>Status</th>
                            <th>Start Date</th>
                            <th width="60px">Action</th>
	        			</tr>
	        		</thead>


            		<tbody>
			            @foreach ($costumercircuits as $costumercircuit)
                            <tr>
                                <td>{{{ $costumercircuit->circuitid }}}</td>
                                <td>{{{ $costumercircuit->namasite }}}</td>
                                <td>{{{ $costumercircuit->alamat }}}</td>
                                <td>{{{ $costumercircuit->layanan }}}</td>
                                <td>{{{ $costumercircuit->bandwidth }}} {{{ $costumercircuit->satuan }}}</td>
                                <td>{{{ $costumercircuit->present()->mrcCircuit }}}</td>
                                <td>{{{ $costumercircuit->circuitidbackhaul }}}</td>
                                <td>{{{ $costumercircuit->circuitidlastmile }}}</td>
                                <td> {{{ $costumercircuit->namavendor }}} </td>
                                <td> {{{ $costumercircuit->present()->mrclastmile }}} </td>
                                <td> {{{ $costumercircuit->present()->untung }}} </td>
                                <td>
                                    @if ( $costumercircuit->status == 'Aktif' )
                                        <span class="label label-success">{{{ $costumercircuit->status }}}</span>
                                    @elseif ( $costumercircuit->status == 'Terminate' )
                                        <span class="label label-important">{{{ $costumercircuit->status }}}</span>
                                    @elseif ( $costumercircuit->status == 'Suspend' )
                                        <span class="label label-warning">{{{ $costumercircuit->status }}}</span>
                                    @endif
                                </td>
                                <td>{{{ $costumercircuit->present()->startDate }}}</td>
                                <td width="60px" class="ac">
                                <a href="{{ URL::route('costumercircuits.show', array($costumercircuit->id)) }}"> {{ Form::button('<i class="glyphicon glyphicon-list"></i>', array('class' => 'btn btn-xs')) }} </a>
                                    <a href="{{ URL::route('costumercircuits.edit', array($costumercircuit->id)) }}"> {{ Form::button('<i class="glyphicon glyphicon-pencil"></i>', array('class' => 'btn btn-xs')) }} </a>
                                    {{ Form::open(array('method' => 'DELETE', 'route' => array('costumercircuits.destroy', $costumercircuit->id), 'style'=>'display:inline-block')) }}
                                            {{ Form::button('<i class="glyphicon glyphicon-trash"></i>', array('type' => 'submit', 'class' => 'btn btn-danger btn-xs')) }}
                                    {{ Form::close() }}
                                </td>
                            </tr>
                        @endforeach                            
            		</tbody>
                    
            		 
            	</table>

           
    <div id="piechart" style="width: 900px; height: 500px;"></div>

@stop


@section('script-bawah')

<script type="text/javascript" language="javascript" class="init">
    $(document).ready(function() {
    	$('#datasbp').DataTable( {
        	"dom": 'T<"clear">lfrtip',
        	"oTableTools": {
        	            "aButtons": [
        	                {
        	                    "sExtends": "pdf",
        	                    "sPdfOrientation": "landscape",
                                "mColumns": [ 0, 1, 2, 3, 4, 5, 6, 7, 8 ]
        	                },
        	                {
        	                    "sExtends": "xls",
                                "mColumns": [ 0, 1, 2, 3, 4, 5, 6, 7, 8 ]
        	                },
        	                {
        	                    "sExtends": "csv",
                                "mColumns": [ 0, 1, 2, 3, 4, 5, 6, 7, 8 ]
        	                },
        	                {
        	                    "sExtends": "copy",
                                "mColumns": [ 0, 1, 2, 3, 4, 5, 6, 7, 8 ]
        	                },
        	                "print"

        	            ]
        	        },            
        } );
    } );
</script>

<script type="text/javascript">
	@foreach ($contacts as $contact)
	$('#contactButton{{{ $contact->id }}}').popover();
	@endforeach
	$('#myButton').popover();
</script>

    

@stop
