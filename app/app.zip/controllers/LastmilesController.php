<?php

class LastmilesController extends BaseController {

	/**
	 * Lastmile Repository
	 *
	 * @var Lastmile
	 */
	protected $lastmile;

	public function __construct(Lastmile $lastmile)
	{
		$this->lastmile = $lastmile;
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$lastmiles = $this->lastmile->all();

		return View::make('lastmiles.index', compact('lastmiles'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		$vendor = Vendor::lists('nama', 'id');
		$circuitidbackhaul = Backhaul::lists('circuitidbackhaul', 'circuitidbackhaul');

		return View::make('lastmiles.create', ['vendor' => $vendor, 'circuitidbackhaul' => $circuitidbackhaul]);
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$inputlastmile = Input::only('circuitidlastmile', 'activated_at', 'vlanid', 'vlanname', 'ipaddressptp', 'blockippubliccustomer', 'layanan', 'bandwidth', 'satuan', 'kawasan', 'keterangan', 'circuitidbackhaul', 'vendor_id', 'status');
		$inputbiaya = Input::only('nrc', 'mrc', 'currency');
		$input = Input::all();

		$validation = Validator::make($input, Lastmile::$rules);

		if ($validation->passes())
		{
			$this->lastmile->create($inputlastmile);
			$circuitidlastmile = Input::get('circuitidlastmile');
			$lastmileini = Lastmile::where('circuitidlastmile', '=', $circuitidlastmile)->first();

			$vendorid = Input::get('vendor_id');

			$namavendor = Vendor::find($vendorid)->pluck('nama');
			$lastmileini->namavendor = $namavendor;
			$lastmileini->save();

			$lastmileini->biayas()->create($inputbiaya);

			if (Input::has('username') and Input::has('password')) 
				{	
					$inputadsl = Input::only('username', 'password');
					$lastmileini->adsls()->create($inputadsl);
				}

			return Redirect::route('lastmiles.index');
		}

		return Redirect::route('lastmiles.create')
			->withInput()
			->withErrors($validation)
			->with('message', 'There were validation errors.');
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$lastmile = $this->lastmile->findOrFail($id);
		$vendor = Vendor::with('contactvendors')->where('id', $lastmile->vendor_id)->first();

		return View::make('lastmiles.show', compact('lastmile', 'vendor'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$lastmile = $this->lastmile->find($id);

		if (is_null($lastmile))
		{
			return Redirect::route('lastmiles.index');
		}

		return View::make('lastmiles.edit', compact('lastmile'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$input = array_except(Input::all(), '_method');
		$validation = Validator::make($input, Lastmile::$rules);

		if ($validation->passes())
		{
			$lastmile = $this->lastmile->find($id);
			$lastmile->update($input);

			return Redirect::route('lastmiles.show', $id);
		}

		return Redirect::route('lastmiles.edit', $id)
			->withInput()
			->withErrors($validation)
			->with('message', 'There were validation errors.');
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$this->lastmile->find($id)->delete();

		return Redirect::route('lastmiles.index');
	}

}
