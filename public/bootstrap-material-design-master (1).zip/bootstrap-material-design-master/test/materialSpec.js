'use strict';

describe('Material', function (){

    //Dummy test just to ensure tests are accurately configured
    it('jquery should be loaded', function () {
        expect($).toBeDefined();
    });
});
